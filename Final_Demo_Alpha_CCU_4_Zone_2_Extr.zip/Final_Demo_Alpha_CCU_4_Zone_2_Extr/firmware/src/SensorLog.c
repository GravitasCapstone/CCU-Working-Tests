/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    sensorlog.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "sensorlog.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and data_to_chars are be defined outside this structure.
 */

SENSORLOG_DATA sensorlogData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void SENSORLOG_Initialize ( void )

  Remarks:
    See prototype in sensorlog.h.
 */


const char datalog_header[] = "Heartbeat,Zone,Temp(F),Temp(C),Humid(%),Pressure(Pa)\n";
char datalog_buffer[50];
char data_to_char[10];
char *com = ",";
char *newline = "\n";

QueueHandle_t dataQueue = NULL;
QueueHandle_t u1command;
QueueHandle_t u2command;
QueueHandle_t u3command;
QueueHandle_t u4command;
QueueHandle_t u5command;
QueueHandle_t u6command;

QueueHandle_t u1Status;
QueueHandle_t u2Status;
QueueHandle_t u3Status;
QueueHandle_t u4Status;
QueueHandle_t u5Status;
QueueHandle_t u6Status;
bool sdReady = false;
bool sdMount = true;
bool sdConfig_read = true;
bool sdSchedule_read = true;
SENSOR_UNIT_INTERFACE_STATE u2redir;

void SENSORLOG_Initialize(void) {
    dataQueue = xQueueCreate(10, sizeof (DATA_TRANSFER));

    u1command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u2command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u3command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u4command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u5command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u6command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));

    u1Status = xQueueCreate(5, sizeof (uint32_t));
    u2Status = xQueueCreate(5, sizeof (uint32_t));
    u3Status = xQueueCreate(5, sizeof (uint32_t));
    u4Status = xQueueCreate(5, sizeof (uint32_t));
    u5Status = xQueueCreate(5, sizeof (uint32_t));
    u6Status = xQueueCreate(5, sizeof (uint32_t));

    sensorlogData.nextstate = SENSORLOG_STATE_WAIT_FOR_SD_MOUNT;
}

/******************************************************************************
  Function:
    void SENSORLOG_Tasks ( void )

  Remarks:
    See prototype in sensorlog.h.
 */


void SENSORLOG_Tasks(void) {
    while (1) {
        switch (sensorlogData.nextstate) {
            case SENSORLOG_STATE_WAIT_FOR_SD_MOUNT:
                if ((sdMount && sdConfig_read && sdSchedule_read)) {
                    sensorlogData.prevstate = SENSORLOG_STATE_WAIT_FOR_SD_MOUNT;
                    sensorlogData.nextstate = SENSORLOG_STATE_DATALOG_SETUP;
                }
                break;

            case SENSORLOG_STATE_DATALOG_SETUP:
                BSP_LEDOn(LED3);
                //                // Open datalog CSV file to write datalog header
                //                datalog = SYS_FS_FileOpen("datalog.csv", (SYS_FS_FILE_OPEN_APPEND_PLUS));
                //                err = SYS_FS_Error();
                //                Nop();
                //                // Write datalog header
                //                datalog_bytes_written = SYS_FS_FileWrite(datalog, datalog_header, strlen(datalog_header));
                //                err = SYS_FS_Error();
                //                Nop();
                //                // Close datalog header
                //                SYS_FS_FileClose(datalog);
                //                err = SYS_FS_Error();
                sdReady = true;
                BSP_LEDOff(LED3);
                sensorlogData.prevstate = SENSORLOG_STATE_DATALOG_SETUP;
                sensorlogData.nextstate = SENSORLOG_STATE_ACTIVE;
                Nop();
                break;


            case SENSORLOG_STATE_ACTIVE:
                while (uxQueueMessagesWaiting(dataQueue)) {
                    BSP_LEDOn(LED3);

                    xQueueReceive(dataQueue, &sensorlogData.sensordata, portMAX_DELAY);

                    // add heartbeat tick to datalog string
                    utoa(data_to_char, sensorlogData.sensordata.pulse, 10);
                    strcpy(datalog_buffer, data_to_char);
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    strcat(datalog_buffer, com);
                    Nop();
                    // add zone number to datalog string
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    utoa(data_to_char, sensorlogData.sensordata.zone, 10);
                    strcat(datalog_buffer, data_to_char);
                    strcat(datalog_buffer, com);
                    Nop();
                    // add temperature in F to datalog string
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    utoa(data_to_char, sensorlogData.sensordata.temperatureF, 10);
                    strcat(datalog_buffer, data_to_char);
                    strcat(datalog_buffer, com);
                    Nop();
                    // add temperature in C to datalog string
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    utoa(data_to_char, sensorlogData.sensordata.temperatureC, 10);
                    strcat(datalog_buffer, data_to_char);
                    strcat(datalog_buffer, com);
                    Nop();
                    // add humidity in % to datalog string
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    utoa(data_to_char, sensorlogData.sensordata.humidity, 10);
                    strcat(datalog_buffer, data_to_char);
                    strcat(datalog_buffer, com);
                    Nop();
                    // add pressure, if available else 0, in ___ to datalog string
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    utoa(data_to_char, sensorlogData.sensordata.pressure, 10);
                    strcat(datalog_buffer, data_to_char);
                    strcat(datalog_buffer, newline);
                    Nop();

                    //                    // Open datalog CSV file to send most recent sensor data to file
                    //                    datalog = SYS_FS_FileOpen("datalog.csv", (SYS_FS_FILE_OPEN_APPEND_PLUS));
                    //                    err = SYS_FS_Error();
                    //                    Nop();
                    //                    // Append datalog
                    //                    datalog_bytes_written = SYS_FS_FileWrite(datalog, datalog_buffer, strlen(datalog_buffer));
                    //                    err = SYS_FS_Error();
                    //                    Nop();
                    //                    // Close datalog file
                    //                    SYS_FS_FileClose(datalog);
                    //                    err = SYS_FS_Error();
                    Nop();

                    // clear buffers
                    memset(data_to_char, '\0', sizeof (data_to_char));
                    memset(datalog_buffer, '\0', sizeof (datalog_buffer));
                    Nop();
                    BSP_LEDOff(LED3);
                    sensorlogData.prevstate = SENSORLOG_STATE_ACTIVE;
                }
                break;

            case SENSORLOG_STATE_IDLE:
                Nop();
                break;
        }

        if ((heartbeat != 0)&&((heartbeat % 17) == 0)) {
            sensorlogData.zonecommand = APP_STATE_USART_TX_RED;
            xQueueSend(u2command, &sensorlogData.zonecommand, 10);
            xQueueSend(u3command, &sensorlogData.zonecommand, 10);
            heartbeat++;
        }
        else if ((heartbeat != 0)&&((heartbeat % 41) == 0)) {
            sensorlogData.zonecommand = APP_STATE_USART_TX_GREEN;
            xQueueSend(u2command, &sensorlogData.zonecommand, 10);
            xQueueSend(u3command, &sensorlogData.zonecommand, 10);
            heartbeat++;
        }
        else if ((heartbeat != 0)&&((heartbeat % 60) == 0)) {
            sensorlogData.zonecommand = APP_STATE_USART_TX_GREEN;
            xQueueSend(u2command, &sensorlogData.zonecommand, 10);
            xQueueSend(u3command, &sensorlogData.zonecommand, 10);
            heartbeat++;
        }
        vTaskDelay(100);


    }
}



/*******************************************************************************
 End of File
 */
