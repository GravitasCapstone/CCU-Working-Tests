/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    u5.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "u5.h"


// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

U5_DATA u5Data;
struct bmp3_dev dev;
struct bmp3_data data;



// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void U5_Initialize ( void )

  Remarks:
    See prototype in u5.h.
 */
double compensate_temperature(const struct bmp3_uncomp_data *uncomp_data, struct bmp3_calib_data *calib_data) {
    uint32_t uncomp_temp = uncomp_data->temperature;
    double partial_data1;
    double partial_data2;

    partial_data1 = (double) (uncomp_temp - calib_data->quantized_calib_data.par_t1);
    partial_data2 = (double) (partial_data1 * calib_data->quantized_calib_data.par_t2);

    /* Update the compensated temperature in calib structure since this is
     * needed for pressure calculation */
    calib_data->quantized_calib_data.t_lin = partial_data2 + (partial_data1 * partial_data1) *
            calib_data->quantized_calib_data.par_t3;

    /* Returns compensated temperature */
    return calib_data->quantized_calib_data.t_lin;

    //    Serial.print("Temperature comped");
}

float bmp3_pow(double b, uint8_t power) {
    float pow_output = 1;

    while (power != 0) {
        pow_output = (float) b * pow_output;
        power--;
    }

    return pow_output;
}

/*!
 * @brief This internal API is used to compensate the raw pressure data and
 * return the compensated pressure data in double data type.
 * For e.g. returns pressure in Pascal p = 95305.295 which is 953.05295 hecto pascal
 */
double compensate_pressure(const struct bmp3_uncomp_data *uncomp_data, const struct bmp3_calib_data *calib_data) {
    const struct bmp3_quantized_calib_data *quantized_calib_data = &calib_data->quantized_calib_data;

    /* Variable to store the compensated pressure */
    double comp_press;

    /* Temporary variables used for compensation */
    double partial_data1;
    double partial_data2;
    double partial_data3;
    double partial_data4;
    double partial_out1;
    double partial_out2;

    partial_data1 = quantized_calib_data->par_p6 * quantized_calib_data->t_lin;
    partial_data2 = quantized_calib_data->par_p7 * bmp3_pow(quantized_calib_data->t_lin, 2);
    partial_data3 = quantized_calib_data->par_p8 * bmp3_pow(quantized_calib_data->t_lin, 3);
    partial_out1 = quantized_calib_data->par_p5 + partial_data1 + partial_data2 + partial_data3;
    partial_data1 = quantized_calib_data->par_p2 * quantized_calib_data->t_lin;
    partial_data2 = quantized_calib_data->par_p3 * bmp3_pow(quantized_calib_data->t_lin, 2);
    partial_data3 = quantized_calib_data->par_p4 * bmp3_pow(quantized_calib_data->t_lin, 3);
    partial_out2 = uncomp_data->pressure *
            (quantized_calib_data->par_p1 + partial_data1 + partial_data2 + partial_data3);
    partial_data1 = bmp3_pow((double) uncomp_data->pressure, 2);
    partial_data2 = quantized_calib_data->par_p9 + quantized_calib_data->par_p10 * quantized_calib_data->t_lin;
    partial_data3 = partial_data1 * partial_data2;
    partial_data4 = partial_data3 + bmp3_pow((double) uncomp_data->pressure, 3) * quantized_calib_data->par_p11;
    comp_press = (partial_out1 + partial_out2 + partial_data4);

    return comp_press;

    //    Serial.print("Pressure Comped");
}

void parse_sensor_data(const uint8_t *reg_data, struct bmp3_uncomp_data *uncomp_data) {
    /* Temporary variables to store the sensor data */
    uint32_t data_xlsb;
    uint32_t data_lsb;
    uint32_t data_msb;

    /* Store the parsed register values for pressure data */
    data_xlsb = (uint32_t) reg_data[0];
    data_lsb = (uint32_t) reg_data[1] << 8;
    data_msb = (uint32_t) reg_data[2] << 16;
    uncomp_data->pressure = data_msb | data_lsb | data_xlsb;

    /* Store the parsed register values for temperature data */
    data_xlsb = (uint32_t) reg_data[3];
    data_lsb = (uint32_t) reg_data[4] << 8;
    data_msb = (uint32_t) reg_data[5] << 16;
    uncomp_data->temperature = data_msb | data_lsb | data_xlsb;
}

int8_t compensate_data(uint8_t sensor_comp,
        const struct bmp3_uncomp_data *uncomp_data,
        struct bmp3_data *comp_data,
        struct bmp3_calib_data *calib_data) {
    int8_t rslt = BMP3_OK;

    if ((uncomp_data != NULL) && (comp_data != NULL) && (calib_data != NULL)) {
        /* If pressure or temperature component is selected */
        if (sensor_comp & (BMP3_PRESS | BMP3_TEMP)) {
            /* Compensate the temperature data */
            comp_data->temperature = compensate_temperature(uncomp_data, calib_data);
        }
        if (sensor_comp & BMP3_PRESS) {
            /* Compensate the pressure data */
            comp_data->pressure = compensate_pressure(uncomp_data, calib_data);
        }

    } else {
        rslt = BMP3_E_NULL_PTR;
    }

    return rslt;
}

void parse_calib_data(const uint8_t *reg_data, struct bmp3_dev *dev) {
    /* Temporary variable to store the aligned trim data */
    struct bmp3_reg_calib_data *reg_calib_data = &dev->calib_data.reg_calib_data;
    struct bmp3_quantized_calib_data *quantized_calib_data = &dev->calib_data.quantized_calib_data;

    /* Temporary variable */
    double temp_var;

    /* 1 / 2^8 */
    temp_var = 0.00390625f;
    reg_calib_data->par_t1 = BMP3_CONCAT_BYTES(reg_data[1], reg_data[0]);
    quantized_calib_data->par_t1 = ((double) reg_calib_data->par_t1 / temp_var);
    reg_calib_data->par_t2 = BMP3_CONCAT_BYTES(reg_data[3], reg_data[2]);
    temp_var = 1073741824.0f;
    quantized_calib_data->par_t2 = ((double) reg_calib_data->par_t2 / temp_var);
    reg_calib_data->par_t3 = (int8_t) reg_data[4];
    temp_var = 281474976710656.0f;
    quantized_calib_data->par_t3 = ((double) reg_calib_data->par_t3 / temp_var);
    reg_calib_data->par_p1 = (int16_t) BMP3_CONCAT_BYTES(reg_data[6], reg_data[5]);
    temp_var = 1048576.0f;
    quantized_calib_data->par_p1 = ((double) (reg_calib_data->par_p1 - (16384)) / temp_var);
    reg_calib_data->par_p2 = (int16_t) BMP3_CONCAT_BYTES(reg_data[8], reg_data[7]);
    temp_var = 536870912.0f;
    quantized_calib_data->par_p2 = ((double) (reg_calib_data->par_p2 - (16384)) / temp_var);
    reg_calib_data->par_p3 = (int8_t) reg_data[9];
    temp_var = 4294967296.0f;
    quantized_calib_data->par_p3 = ((double) reg_calib_data->par_p3 / temp_var);
    reg_calib_data->par_p4 = (int8_t) reg_data[10];
    temp_var = 137438953472.0f;
    quantized_calib_data->par_p4 = ((double) reg_calib_data->par_p4 / temp_var);
    reg_calib_data->par_p5 = BMP3_CONCAT_BYTES(reg_data[12], reg_data[11]);

    /* 1 / 2^3 */
    temp_var = 0.125f;
    quantized_calib_data->par_p5 = ((double) reg_calib_data->par_p5 / temp_var);
    reg_calib_data->par_p6 = BMP3_CONCAT_BYTES(reg_data[14], reg_data[13]);
    temp_var = 64.0f;
    quantized_calib_data->par_p6 = ((double) reg_calib_data->par_p6 / temp_var);
    reg_calib_data->par_p7 = (int8_t) reg_data[15];
    temp_var = 256.0f;
    quantized_calib_data->par_p7 = ((double) reg_calib_data->par_p7 / temp_var);
    reg_calib_data->par_p8 = (int8_t) reg_data[16];
    temp_var = 32768.0f;
    quantized_calib_data->par_p8 = ((double) reg_calib_data->par_p8 / temp_var);
    reg_calib_data->par_p9 = (int16_t) BMP3_CONCAT_BYTES(reg_data[18], reg_data[17]);
    temp_var = 281474976710656.0f;
    quantized_calib_data->par_p9 = ((double) reg_calib_data->par_p9 / temp_var);
    reg_calib_data->par_p10 = (int8_t) reg_data[19];
    temp_var = 281474976710656.0f;
    quantized_calib_data->par_p10 = ((double) reg_calib_data->par_p10 / temp_var);
    reg_calib_data->par_p11 = (int8_t) reg_data[20];
    temp_var = 36893488147419103232.0f;
    quantized_calib_data->par_p11 = ((double) reg_calib_data->par_p11 / temp_var);

    //    Serial.print("Calib Data parsed");
}

/*!
 * @brief This internal API is used to compensate the raw temperature data and
 * return the compensated temperature data in double data type.
 * for e.g. returns temperature 24.26 deg Celsius
 */




//void setup() {
//  // put your setup code here, to run once:s
//  Serial.begin(9600);
//  Serial2.begin(9600);

uint8_t calib_data_1[21] = {0xD2, 0x69, 0x62, 0x49, 0xF6, 0x92, 0xFE,
    0x1E, 0xF5, 0x23, 0x00, 0x7F, 0x65, 0xE7, 0x7B, 0xF3, 0xF6, 0x7B,
    0x42, 0x0A, 0xC4};


//}



struct bmp3_uncomp_data uncomp_data;
uint8_t sensor_comp = BMP3_PRESS;

void U5_Initialize(void) {
    u5Data.prevstate = APP_STATE_USART_INIT;
    u5Data.handle = DRV_USART_Open(DRV_USART_INDEX_4, DRV_IO_INTENT_READWRITE);
    if (u5Data.handle == DRV_HANDLE_INVALID) {
        u5Data.error = USART_OPEN_FAIL;
    } else {
        u5Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
        u5Data.error = NO_ERROR;
        BSP_LEDStateSet(U5_EN, 0);
    }
    u5Data.data_ptr = &u5Data.zonedata;
    parse_calib_data(calib_data_1, &dev);
}

/******************************************************************************
  Function:
    void U5_Tasks ( void )

  Remarks:
    See prototype in u5.h.
 */
void U5_Tasks(void) {
    while (1) {
        if ((u5Data.error == NO_ERROR) && ((sdMount && sdConfig_read && sdSchedule_read) == true)) {
            switch (u5Data.nextstate) {
                case APP_STATE_USART_TX:
                    // set 485 to TX
                    BSP_LEDStateSet(U5_EN, 1);
                    // send data
                    DRV_USART_Write(u5Data.handle, &u5Data.command, sizeof (char));
                    u5Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u5Data.nextstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                    vTaskDelay(10);
                    break;
                case APP_STATE_USART_WAIT_FOR_TX_COMPLETION:
                    if (DRV_USART_TRANSFER_STATUS_TRANSMIT_EMPTY & DRV_USART_TransferStatus(u5Data.handle)) {
                        // TX complete and prep for RX
                        BSP_LEDStateSet(U5_EN, 0);
                        u5Data.prevstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                        u5Data.nextstate = APP_STATE_USART_IDLE;
                    }
                    break;
                case APP_STATE_USART_RX:
                    DRV_USART_Read(u5Data.handle, &u5Data.data.rec[0], 10);
                    u5Data.prevstate = APP_STATE_USART_RX;
                    u5Data.nextstate = APP_STATE_DATA_DECODE;
                    Nop();
                    vTaskDelay(10);
                    break;
                case APP_STATE_DATA_DECODE:
                    u5Data.data.temp_bytes[0] = u5Data.data.rec[0];
                    u5Data.data.temp_bytes[1] = u5Data.data.rec[1];

                    u5Data.data.temp_raw = (unsigned int) (u5Data.data.temp_bytes[1] << 8 | u5Data.data.temp_bytes[0]);

                    u5Data.data.temp_Celcius = ((u5Data.data.temp_raw * 165) / 65536) - 40;
                    u5Data.data.temp_Fahrenheit = u5Data.data.temp_Celcius * 9 / 5 + 32;

                    u5Data.data.humid_bytes[0] = u5Data.data.rec[2];
                    u5Data.data.humid_bytes[1] = u5Data.data.rec[3];

                    u5Data.data.humid_raw = (u5Data.data.humid_bytes[1] << 8 | u5Data.data.humid_bytes[0]);

                    u5Data.data.humid = u5Data.data.humid_raw * 100 / 65536;

                    u5Data.data.pressure_bytes[0] = u5Data.data.rec[4];
                    u5Data.data.reg_data[0] = u5Data.data.pressure_bytes[0];
                    u5Data.data.pressure_bytes[1] = u5Data.data.rec[5];
                    u5Data.data.reg_data[1] = u5Data.data.pressure_bytes[1];
                    u5Data.data.pressure_bytes[2] = u5Data.data.rec[6];
                    u5Data.data.reg_data[2] = u5Data.data.pressure_bytes[2];

                    u5Data.data.temp_bmp_bytes[0] = u5Data.data.rec[7];
                    u5Data.data.reg_data[3] = u5Data.data.temp_bmp_bytes[1];
                    u5Data.data.temp_bmp_bytes[1] = u5Data.data.rec[8];
                    u5Data.data.reg_data[4] = u5Data.data.temp_bmp_bytes[2];
                    u5Data.data.temp_bmp_bytes[2] = u5Data.data.rec[9];
                    u5Data.data.reg_data[5] = u5Data.data.temp_bmp_bytes[3];
                    
                    parse_sensor_data(u5Data.data.reg_data,&uncomp_data);
                    u5Data.data.result = compensate_data(sensor_comp, &uncomp_data, &data, &dev.calib_data);
                    u5Data.data.pressure = data.pressure;
                    
                    u5Data.zonedata.date = CURRENT_TIME;
                    u5Data.zonedata.zone = 5;
                    u5Data.zonedata.temperatureC = u5Data.data.temp_Celcius;
                    u5Data.zonedata.temperatureF = u5Data.data.temp_Fahrenheit;
                    u5Data.zonedata.humidity = u5Data.data.humid;
                    u5Data.zonedata.pressure = u5Data.data.pressure;

                    Nop();
                    xQueueSend(dataQueue, u5Data.data_ptr, 10);
                    xQueueSend(u5Status, &u5Data.zonedata.temperatureF, 10);
                    u5Data.data_repeat = 0;
                    Nop();

                    u5Data.prevstate = APP_STATE_DATA_DECODE;
                    u5Data.nextstate = APP_STATE_USART_IDLE;
                    break;

                case APP_STATE_USART_TX_DATA_REQ:
                    u5Data.command = DATA_REQ;
                    u5Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_RED:
                    u5Data.command = HEATING;
                    u5Data.prevstate = APP_STATE_USART_TX_RED;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_GREEN:
                    u5Data.command = IDLE;
                    u5Data.prevstate = APP_STATE_USART_TX_GREEN;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_BLUE:
                    u5Data.command = COOLING;
                    u5Data.prevstate = APP_STATE_USART_TX_BLUE;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_IDLE:
                    if (DRV_USART_TRANSFER_STATUS_RECEIVER_DATA_PRESENT & DRV_USART_TransferStatus(u5Data.handle)) {
                        // Input detected
                        u5Data.nextstate = APP_STATE_USART_RX;
                    } else if (uxQueueMessagesWaiting(u5command)) {
                        // if system command in waitng, read it to change state 
                        xQueueReceive(u5command, &u5Data.sys_command, 20);
                        u5Data.nextstate = u5Data.sys_command;
                        u5Data.data_repeat = 0;
                    } else {
                        u5Data.data_repeat++;
                        if (u5Data.data_repeat >= 100) {
                            u5Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
                            u5Data.data_repeat = 0;
                        } else {
                            u5Data.nextstate = APP_STATE_USART_IDLE;
                        }
                    }
                    u5Data.prevstate = APP_STATE_USART_IDLE;
                    vTaskDelay(50);
                    break;

                default:
                    u5Data.nextstate = APP_STATE_USART_IDLE;
                    break;

            }
            vTaskDelay(10);
            Nop();
        } else if (sdReady == false) {
            vTaskDelay(1000);
        } else {
            // Error Processing
            U5_Initialize();
            vTaskDelay(100);
        }
    }
}



/*******************************************************************************
 End of File
 */
