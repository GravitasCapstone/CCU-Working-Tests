/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    systemcontrol.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "systemcontrol.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

SYSTEMCONTROL_DATA systemcontrolData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void SYSTEMCONTROL_Initialize ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

bool sdMount, sdConfig_read, sdSchedule_read, logReady;
bool z1En, z2En, z3En, z4En;
SYS_FS_HANDLE datalog, config, schedule;
SYS_FS_RESULT mount, drive_set, unmount;
SYS_FS_RESULT datalog_close, config_close, schedule_close;
SYS_FS_ERROR err;
size_t datalog_bytes_written, config_bytes_read, schedule_bytes_read;
size_t config_file_size, schedule_file_size;

QueueHandle_t u1command;
QueueHandle_t u2command;
QueueHandle_t u3command;
QueueHandle_t u4command;
QueueHandle_t u5command;
QueueHandle_t u6command;

QueueHandle_t u1Status;
QueueHandle_t u2Status;
QueueHandle_t u3Status;
QueueHandle_t u4Status;
QueueHandle_t u5Status;
QueueHandle_t u6Status;

QueueHandle_t ccu_command;

char *com = ",";
char *newline = "\n";

char config_buff[500];
char *res[80];
char *config_table[40][2];

char schedule_buff[10000];
char *res2[60];
char *schedule_table [10][6];

char *res3[5];

int lowpoint[500];

int i, j, k;
uint8_t num_update = 0;
uint8_t num_actions = 0;

uint8_t damper_command, hvac_command;
uint16_t ccu_out_command;
/*  128,64,32,16,8,4,2,1
 * damper_command -> 8 bit masking command to carry damper instructions
 *  D8,D7,D6,D5,D4,D3,D2,D1
 * hvac_command -> 8 bit masking command to carry AHU control line instructions
 *  NULL,H1,H2,C1,C2,F1,F2,F3
 * ccu_out_command -> 16 bit command to send instructions to the output of the CCU
 *  NULL,H1,H2,C1,C2,F1,F2,F3,D8,D7,D6,D5,D4,D3,D2,D1
 */

bool u1En, u2En, u3En, u4En;

SENSOR_UNIT_INTERFACE_STATE send_idle = APP_STATE_USART_TX_GREEN;

void SYSTEMCONTROL_Initialize(void) {
    u1command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u2command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u3command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u4command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u5command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u6command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));

    u1Status = xQueueCreate(4, sizeof (uint32_t));
    u2Status = xQueueCreate(4, sizeof (uint32_t));
    u3Status = xQueueCreate(4, sizeof (uint32_t));
    u4Status = xQueueCreate(4, sizeof (uint32_t));
    u5Status = xQueueCreate(4, sizeof (uint32_t));
    u6Status = xQueueCreate(4, sizeof (uint32_t));

    ccu_command = xQueueCreate(2, sizeof (ccu_out_command));

    systemcontrolData.hvac_mode = HVAC_IDLE;

    systemcontrolData.prevstate = SYSTEMCONTROL_STATE_INIT;
    systemcontrolData.nextstate = SYSTEMCONTROL_STATE_MOUNT_SD;

}

/******************************************************************************
  Function:
    void SYSTEMCONTROL_Tasks ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

void SYSTEMCONTROL_Tasks(void) {
    while (1) {
        switch (systemcontrolData.nextstate) {
            case SYSTEMCONTROL_STATE_MOUNT_SD:
                mount = SYS_FS_Mount("/dev/mmcblka1", "/mnt/myDrive", FAT, 0, NULL);
                if (mount == 0) {
                    sdMount = true;
                    BSP_LEDOn(LED3);
                    drive_set = SYS_FS_CurrentDriveSet("/mnt/myDrive");
                    err = SYS_FS_Error();
                    systemcontrolData.prevstate = SYSTEMCONTROL_STATE_MOUNT_SD;
                    systemcontrolData.nextstate = SYSTEMCONTROL_STATE_READ_CONFIG;
                    Nop();
                } else {
                    err = SYS_FS_Error();
                    BSP_LEDToggle(LED3);
                    Nop();
                }
                break;

            case SYSTEMCONTROL_STATE_READ_CONFIG:
                BSP_LEDOn(LED3);
                logReady = false;
                config = SYS_FS_FileOpen("config.csv", (SYS_FS_FILE_OPEN_READ));
                if (config == SYS_FS_HANDLE_INVALID) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_file_size = SYS_FS_FileSize(config);
                if (config_file_size == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_bytes_read = SYS_FS_FileRead(config, config_buff, config_file_size);
                if (config_bytes_read == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_close = SYS_FS_FileClose(config);
                if (config_close == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                if (err != SYS_FS_ERROR_OK) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_READ_CONFIG;
                systemcontrolData.nextstate = SYSTEMCONTROL_STATE_PROCESS_CONFIG;
                BSP_LEDOff(LED3);

                Nop();

                break;

            case SYSTEMCONTROL_STATE_PROCESS_CONFIG:
                Nop();
                // break file into tokens based on comma and newline
                res[i] = strtok(config_buff, "\n,");
                while (res[i] != NULL) {
                    res[++i] = strtok(NULL, "\n,");
                }

                // build a table so that information can be processed by eliminating
                // the left column from the file
                for (j = 0; j <= 40; j++) {
                    config_table[j][0] = res[2 * j];
                    config_table[j][1] = res[2 * j + 1];
                }
                Nop();

                for (i = 0; i < 4; i++) { // read zone info
                    // check if a zone is active
                    j = atoi(config_table[i + 1][1]);
                    systemcontrolData.config.zone[i] = j;
                }
                for (i = 0; i < 8; i++) { // read damper info
                    // check if damper is active and normally open or closed
                    j = atoi(config_table[i + 5][1]);
                    systemcontrolData.config.damper[i] = j;
                }
                for (i = 0; i < 8; i++) { // read damper in zone info
                    // check what zone a damper sends air to
                    j = atoi(config_table[i + 13][1]);
                    systemcontrolData.config.damper_in_zone[i] = j;
                }
                for (i = 0; i < 8; i++) { // read airflow mode
                    j = atoi(config_table[i + 21][1]);
                    systemcontrolData.config.damper_mode[i] = j;
                }
                i = 29;
                systemcontrolData.config.ahu.cSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cAnt, config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cRunT, config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cCycleT, config_table[i++][1]);
                systemcontrolData.config.ahu.hSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hAnt, config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hRunT, config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hCycleT, config_table[i++][1]);
                systemcontrolData.config.ahu.overTemp = atoi(config_table[i++][1]);

                Nop();
                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_PROCESS_CONFIG;
                systemcontrolData.nextstate = SYSTEMCONTROL_STATE_APPLY_CONFIG;

                break;
            case SYSTEMCONTROL_STATE_APPLY_CONFIG:
                // if zone is enabled, then generate damper commands tied to it
                // commands such as sending or blocking air and sending warm or cool air
                i = 0;
                if (systemcontrolData.config.zone[i]) {
                    // zone 1 
                    z1En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone1.dampers = systemcontrolData.zone1.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone1.cut_air_command = systemcontrolData.zone1.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone1.allow_air_command = systemcontrolData.zone1.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone1.send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone1.allow_air_command;
                                systemcontrolData.zone1.send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone1.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone1.send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone1.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone1.send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone1.cut_air_command;
                            }
                        }
                    }
                } else {
                    z1En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 2 
                    z2En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone2.dampers = systemcontrolData.zone2.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone2.cut_air_command = systemcontrolData.zone2.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone2.allow_air_command = systemcontrolData.zone2.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone2.send_heat = systemcontrolData.zone2.send_heat | systemcontrolData.zone2.allow_air_command;
                                systemcontrolData.zone2.send_cool = systemcontrolData.zone2.send_cool | systemcontrolData.zone2.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone2.send_heat = systemcontrolData.zone2.send_heat | systemcontrolData.zone2.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone2.send_cool = systemcontrolData.zone2.send_cool | systemcontrolData.zone2.cut_air_command;
                            }
                        }
                    }
                } else {
                    z2En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 3 
                    z3En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone3.dampers = systemcontrolData.zone3.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone3.cut_air_command = systemcontrolData.zone3.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone3.allow_air_command = systemcontrolData.zone3.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone3.send_heat = systemcontrolData.zone3.send_heat | systemcontrolData.zone3.allow_air_command;
                                systemcontrolData.zone3.send_cool = systemcontrolData.zone3.send_cool | systemcontrolData.zone3.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone3.send_heat = systemcontrolData.zone3.send_heat | systemcontrolData.zone3.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone3.send_cool = systemcontrolData.zone3.send_cool | systemcontrolData.zone3.cut_air_command;
                            }
                        }
                    }
                } else {
                    z3En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 4 
                    z4En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone4.dampers = systemcontrolData.zone4.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone4.cut_air_command = systemcontrolData.zone4.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone4.allow_air_command = systemcontrolData.zone4.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone4.send_heat = systemcontrolData.zone4.send_heat | systemcontrolData.zone4.allow_air_command;
                                systemcontrolData.zone4.send_cool = systemcontrolData.zone4.send_cool | systemcontrolData.zone4.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone4.send_heat = systemcontrolData.zone4.send_heat | systemcontrolData.zone4.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone4.send_cool = systemcontrolData.zone4.send_cool | systemcontrolData.zone4.cut_air_command;
                            }
                        }
                    }
                } else {
                    z4En = false;
                }
                i++;


                int all_active_dampers = systemcontrolData.zone1.dampers | systemcontrolData.zone2.dampers | systemcontrolData.zone3.dampers | systemcontrolData.zone4.dampers;
                int all_allow_air = systemcontrolData.zone1.allow_air_command | systemcontrolData.zone2.allow_air_command | systemcontrolData.zone3.allow_air_command | systemcontrolData.zone4.allow_air_command;
                int all_block_air = systemcontrolData.zone1.cut_air_command | systemcontrolData.zone2.cut_air_command | systemcontrolData.zone3.cut_air_command | systemcontrolData.zone4.cut_air_command;
                int all_send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone2.send_heat | systemcontrolData.zone3.send_heat | systemcontrolData.zone4.send_heat;
                int all_send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone2.send_cool | systemcontrolData.zone3.send_cool | systemcontrolData.zone4.send_cool;

                //                while (BSP_SwitchStateGet(B1)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_active_dampers & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B2)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_allow_air & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B3)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_block_air & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B4)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_send_heat & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B5)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_send_cool & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();

                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_APPLY_CONFIG;
                systemcontrolData.nextstate = SYSTEMCONTROL_STATE_READ_SCHEDULE;
                Nop();
                sdConfig_read = true;
                break;

            case SYSTEMCONTROL_STATE_READ_SCHEDULE:
                BSP_LEDOn(LED3);
                // need to work with bret on doing a switch case for choosing a schedule based on user input

                schedule = SYS_FS_FileOpen("schedule.csv", (SYS_FS_FILE_OPEN_READ));
                if (schedule == SYS_FS_HANDLE_INVALID) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_file_size = SYS_FS_FileSize(schedule);
                if (schedule_file_size == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_bytes_read = SYS_FS_FileRead(schedule, schedule_buff, schedule_file_size);
                if (schedule_bytes_read == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_close = SYS_FS_FileClose(schedule);
                if (schedule_close == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                if (err != SYS_FS_ERROR_OK) {
                    BSP_LEDOn(LED2);
                    Nop();
                }

                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_READ_SCHEDULE;
                systemcontrolData.nextstate = SYSTEMCONTROL_STATE_PROCESS_SCHEDULE;
                BSP_LEDOff(LED3);
                sdConfig_read = true;
                Nop();
                break;

            case SYSTEMCONTROL_STATE_PROCESS_SCHEDULE:
                i = 0;
                res2[i] = strtok(schedule_buff, "\n,");
                while (res2[i] != NULL) {
                    res2[++i] = strtok(NULL, "\n,");
                }

                for (j = 0; j <= 10; j++) {
                    schedule_table[j][0] = res2[6 * j];
                    schedule_table[j][1] = res2[6 * j + 1];
                    schedule_table[j][2] = res2[6 * j + 2];
                    schedule_table[j][3] = res2[6 * j + 3];
                    schedule_table[j][4] = res2[6 * j + 4];
                    schedule_table[j][5] = res2[6 * j + 5];
                }

                for (i = 0; i < 4; i++) { // read zone info
                    j = atoi(config_table[i + 1][4]);
                    k = atoi(schedule_table[i + 1][5]);
                    systemcontrolData.zL[i] = j;
                    systemcontrolData.zH[i] = k;
                }
                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_PROCESS_SCHEDULE;
                systemcontrolData.nextstate = SYSTEMCONTROL_GET_DATA;
                sdSchedule_read = true;
                logReady = true;
                break;

            case SYSTEMCONTROL_GET_DATA:
                num_update = 0;
                if (uxQueueMessagesWaiting(u1Status)) {
                    xQueueReceive(u1Status, &systemcontrolData.z1.status.temperatureF, 10);
                    num_update++;
                }
                if (uxQueueMessagesWaiting(u2Status)) {
                    xQueueReceive(u2Status, &systemcontrolData.z2.status.temperatureF, 10);
                    num_update++;
                }
                if (uxQueueMessagesWaiting(u3Status)) {
                    xQueueReceive(u3Status, &systemcontrolData.z3.status.temperatureF, 10);
                    num_update++;
                }
                if (uxQueueMessagesWaiting(u4Status)) {
                    xQueueReceive(u4Status, &systemcontrolData.z4.status.temperatureF, 10);
                    num_update++;
                }
                if (uxQueueMessagesWaiting(u5Status)) {
                    xQueueReceive(u5Status, &systemcontrolData.e1.status.temperatureF, 10);
                    num_update++;
                }
                if (uxQueueMessagesWaiting(u6Status)) {
                    xQueueReceive(u6Status, &systemcontrolData.e2.status.temperatureF, 10);
                    num_update++;
                }

                if (num_update) {
                    systemcontrolData.nextstate = SYSTEMCONTROL_THRESHOLD_CHECK;
                    systemcontrolData.prevstate = SYSTEMCONTROL_GET_DATA;
                } else {
                    systemcontrolData.nextstate = SYSTEMCONTROL_GET_DATA;
                }
                break;



            case SYSTEMCONTROL_GET_HVAC_MODE:
                switch (systemcontrolData.hvac_mode) {
                    case HVAC_IDLE:
                        //                        // find rule that needs to be met
                        //                        for (i = 0; i < 10; i++) {
                        //                            char asdf[8] = systemcontrolData.rule[i].start_time;
                        //                            res3[j] = strtok(asdf, ":");
                        //                        }
                        break;
                    case HVAC_COOL_DOWN:
                        break;
                    case HVAC_HEATING:
                        break;
                    case HVAC_COOLING:
                        break;
                    case HVAC_SPIN_DOWN:
                        break;
                    case HVAC_COOL_PREP:
                        break;
                    case HVAC_HEAT_PREP:
                        break;
                    default:
                        break;
                }
                break;
            case SYSTEMCONTROL_THRESHOLD_CHECK:
                systemcontrolData.needCool = 0;
                systemcontrolData.needHeat = 0;

                if ((systemcontrolData.z1.status.temperatureF < systemcontrolData.zL[0]) && z1En) {
                    systemcontrolData.needHeat++;
                    systemcontrolData.z1.zone_needs_mode = ZONE_NEED_HEAT;
                } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[0]) && z1En) {
                    systemcontrolData.needCool++;
                    systemcontrolData.z1.zone_needs_mode = ZONE_NEED_COOL;
                } else {
                    systemcontrolData.z1.zone_needs_mode = ZONE_IDLE;
                }

                if ((systemcontrolData.z2.status.temperatureF < systemcontrolData.zL[1]) && z2En) {
                    systemcontrolData.needHeat++;
                    systemcontrolData.z2.zone_needs_mode = ZONE_NEED_HEAT;
                } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[1]) && z2En) {
                    systemcontrolData.needCool++;
                    systemcontrolData.z2.zone_needs_mode = ZONE_NEED_COOL;
                } else {
                    systemcontrolData.z2.zone_needs_mode = ZONE_IDLE;
                }

                if ((systemcontrolData.z3.status.temperatureF < systemcontrolData.zL[2]) && z3En) {
                    systemcontrolData.needHeat++;
                    systemcontrolData.z3.zone_needs_mode = ZONE_NEED_HEAT;
                } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[2]) && z3En) {
                    systemcontrolData.needCool++;
                    systemcontrolData.z3.zone_needs_mode = ZONE_NEED_COOL;
                } else {
                    systemcontrolData.z3.zone_needs_mode = ZONE_IDLE;
                }

                if ((systemcontrolData.z4.status.temperatureF < systemcontrolData.zL[3]) && z4En) {
                    systemcontrolData.needHeat++;
                    systemcontrolData.z4.zone_needs_mode = ZONE_NEED_HEAT;
                } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[3]) && z4En) {
                    systemcontrolData.needCool++;
                    systemcontrolData.z4.zone_needs_mode = ZONE_NEED_COOL;
                } else {
                    systemcontrolData.z4.zone_needs_mode = ZONE_IDLE;
                }


                if (systemcontrolData.needCool || systemcontrolData.needHeat) {
                    systemcontrolData.nextstate = SYSTEMCONTROL_GROUP_NEEDS;
                    systemcontrolData.prevstate = SYSTEMCONTROL_THRESHOLD_CHECK;
                } else {
                    systemcontrolData.nextstate = SYSTEMCONTROL_GET_DATA;
                    systemcontrolData.prevstate = SYSTEMCONTROL_THRESHOLD_CHECK;
                }
                break;

            case SYSTEMCONTROL_GROUP_NEEDS:
                damper_command = 0;
                hvac_command = 0;
                num_actions = 0;

                if (systemcontrolData.needCool >= systemcontrolData.needHeat) {
                    // cooling needed
                    systemcontrolData.active_sensor_state = APP_STATE_USART_TX_BLUE;
                    if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_COOL) {
                        damper_command |= systemcontrolData.zone1.send_cool;
                        if (systemcontrolData.z1.zone_in_mode != ZONE_NEED_COOL) {
                            xQueueSend(u1command, &systemcontrolData.active_sensor_state, 10);
                            systemcontrolData.z1.zone_in_mode = ZONE_NEED_COOL;
                        }
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone1.cut_air_command;
                        systemcontrolData.z1.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_COOL) {
                        damper_command |= systemcontrolData.zone2.send_cool;
                        if (systemcontrolData.z2.zone_in_mode != ZONE_NEED_COOL) {
                            xQueueSend(u2command, &systemcontrolData.active_sensor_state, 10);
                            systemcontrolData.z2.zone_in_mode = ZONE_NEED_COOL;
                        }
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone2.cut_air_command;
                        systemcontrolData.z2.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_COOL) {
                        damper_command |= systemcontrolData.zone3.send_cool;
                        if (systemcontrolData.z3.zone_in_mode != ZONE_NEED_COOL) {
                            xQueueSend(u3command, &systemcontrolData.active_sensor_state, 10);
                            systemcontrolData.z3.zone_in_mode = ZONE_NEED_COOL;
                        }
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone3.cut_air_command;
                        systemcontrolData.z3.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_COOL) {
                        damper_command |= systemcontrolData.zone4.send_cool;
                        if (systemcontrolData.z4.zone_in_mode != ZONE_NEED_COOL) {
                            xQueueSend(u4command, &systemcontrolData.active_sensor_state, 10);
                            systemcontrolData.z4.zone_in_mode = ZONE_NEED_COOL;
                        }
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone4.cut_air_command;
                        systemcontrolData.z4.zone_needs_mode = ZONE_IDLE;
                    }

                    // if 1 then fan 1
                    // if 2-3 then fan 2
                    // if 4 then fan 3
                    if (num_actions == 1) {
                        hvac_command |= 4; // fan speed  
                    } else if ((num_actions == 2) || (num_actions == 3)) {
                        hvac_command |= 2; // fan speed 2

                    } else if (num_actions == 4) {
                        hvac_command |= 1; // fan speed 3

                    } else {
                        Nop();
                    }

                    // if > 2 c2 else c1
                    if (num_actions > 2) {
                        hvac_command |= 8;
                    } else {
                        hvac_command |= 16;
                    }


                } else {
                    // heating needed
                    systemcontrolData.active_sensor_state = APP_STATE_USART_TX_RED;
                    if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_HEAT) {
                        damper_command |= systemcontrolData.zone1.send_heat;
                        xQueueSend(u1command, &systemcontrolData.active_sensor_state, 10);
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone1.cut_air_command;
                        systemcontrolData.z1.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_HEAT) {
                        damper_command |= systemcontrolData.zone2.send_heat;
                        xQueueSend(u2command, &systemcontrolData.active_sensor_state, 10);
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone2.cut_air_command;
                        systemcontrolData.z2.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_HEAT) {
                        damper_command |= systemcontrolData.zone3.send_heat;
                        xQueueSend(u3command, &systemcontrolData.active_sensor_state, 10);
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone3.cut_air_command;
                        systemcontrolData.z3.zone_needs_mode = ZONE_IDLE;
                    }

                    if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_HEAT) {
                        damper_command |= systemcontrolData.zone4.send_heat;
                        xQueueSend(u4command, &systemcontrolData.active_sensor_state, 10);
                        num_actions++;
                    } else {
                        damper_command |= systemcontrolData.zone4.cut_air_command;
                        systemcontrolData.z4.zone_needs_mode = ZONE_IDLE;
                    }


                    // if 1 then fan 1
                    // if 2-3 then fan 2
                    // if 4 then fan 3
                    if (num_actions == 1) {
                        hvac_command |= 4; // fan speed  
                    } else if ((num_actions == 2) || (num_actions == 3)) {
                        hvac_command |= 2; // fan speed 2

                    } else if (num_actions == 4) {
                        hvac_command |= 1; // fan speed 3

                    } else {
                        Nop();
                    }
                    // if > 2 h2 else h1
                    if (num_actions > 2) {
                        hvac_command |= 32;
                    } else {
                        hvac_command |= 64;
                    }
                }

                // do idle queue commands
                if ((systemcontrolData.z1.zone_needs_mode = ZONE_IDLE) && (systemcontrolData.z1.zone_in_mode != ZONE_IDLE)) {
                    xQueueSend(u1command, &send_idle, 10);
                    systemcontrolData.z1.zone_in_mode = ZONE_IDLE;
                }
                if ((systemcontrolData.z2.zone_needs_mode = ZONE_IDLE) && (systemcontrolData.z1.zone_in_mode != ZONE_IDLE)) {
                    xQueueSend(u2command, &send_idle, 10);
                    systemcontrolData.z2.zone_in_mode = ZONE_IDLE;
                }
                if ((systemcontrolData.z3.zone_needs_mode = ZONE_IDLE) && (systemcontrolData.z1.zone_in_mode != ZONE_IDLE)) {
                    xQueueSend(u3command, &send_idle, 10);
                    systemcontrolData.z3.zone_in_mode = ZONE_IDLE;
                }
                if ((systemcontrolData.z4.zone_needs_mode = ZONE_IDLE) && (systemcontrolData.z1.zone_in_mode != ZONE_IDLE)) {
                    xQueueSend(u4command, &send_idle, 10);
                    systemcontrolData.z4.zone_in_mode = ZONE_IDLE;
                }
                
                systemcontrolData.nextstate = SYSTEMCONTROL_ACT;
                systemcontrolData.prevstate = SYSTEMCONTROL_GROUP_NEEDS;
                break;


            case SYSTEMCONTROL_DETERMINE_NEXT_ACTION:
                Nop();
                break;

            case SYSTEMCONTROL_ACT:

                ccu_out_command = (hvac_command << 8) | damper_command;

                xQueueSend(ccu_command, &ccu_out_command, 10);

                systemcontrolData.nextstate = SYSTEMCONTROL_GET_DATA;
                systemcontrolData.prevstate = SYSTEMCONTROL_ACT;
                break;

            default:
                Nop();
                break;
        }
        Nop();
        vTaskDelay(100);
    }
}


/*******************************************************************************
 End of File
 */
