/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    u4.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "u4.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

U4_DATA u4Data;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void U4_Initialize ( void )

  Remarks:
    See prototype in u4.h.
 */




void U4_Initialize(void) {
    u4Data.prevstate = APP_STATE_USART_INIT;
    u4Data.handle = DRV_USART_Open(DRV_USART_INDEX_3, DRV_IO_INTENT_READWRITE);
    if (u4Data.handle == DRV_HANDLE_INVALID) {
        u4Data.error = USART_OPEN_FAIL;
    } else {
        u4Data.nextstate = APP_STATE_USART_TX_GREEN;
        u4Data.error = NO_ERROR;
        BSP_LEDStateSet(U4_EN, 0);
    }
    u4Data.data_ptr = &u4Data.zonedata;
}

/******************************************************************************
  Function:
    void U4_Tasks ( void )

  Remarks:
    See prototype in u4.h.
 */
void U4_Tasks(void) {
    while (1) {
        if ((u4Data.error == NO_ERROR) && (sdReady == true) && (z4En == true)) {
            switch (u4Data.nextstate) {
                case APP_STATE_USART_TX:
                    // set 485 to TX
                    BSP_LEDStateSet(U4_EN, 1);
                    // send data
                    DRV_USART_Write(u4Data.handle, &u4Data.command, sizeof (u4Data.command));
                    u4Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u4Data.nextstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                    vTaskDelay(10);
                    break;
                case APP_STATE_USART_WAIT_FOR_TX_COMPLETION:
                    if (DRV_USART_TRANSFER_STATUS_TRANSMIT_EMPTY & DRV_USART_TransferStatus(u4Data.handle)) {
                        // TX complete and prep for RX
                        BSP_LEDStateSet(U4_EN, 0);
                        u4Data.prevstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                        u4Data.nextstate = APP_STATE_USART_IDLE;
                    }
                    break;
                case APP_STATE_USART_RX:
                    DRV_USART_Read(u4Data.handle, &u4Data.data.rec[0], 4);
                    u4Data.prevstate = APP_STATE_USART_RX;
                    u4Data.nextstate = APP_STATE_DATA_DECODE;
                    Nop();
                    vTaskDelay(10);
                    break;
                case APP_STATE_DATA_DECODE:
                    u4Data.data.temp_bytes[0] = u4Data.data.rec[0];
                    u4Data.data.temp_bytes[1] = u4Data.data.rec[1];

                    u4Data.data.temp_raw = (unsigned int) (u4Data.data.temp_bytes[1] << 8 | u4Data.data.temp_bytes[0]);

                    u4Data.data.temp_Celcius = ((u4Data.data.temp_raw * 165) / 65536) - 40;
                    u4Data.data.temp_Fahrenheit = u4Data.data.temp_Celcius * 9 / 5 + 32;

                    u4Data.data.humid_bytes[0] = u4Data.data.rec[2];
                    u4Data.data.humid_bytes[1] = u4Data.data.rec[3];

                    u4Data.data.humid_raw = (u4Data.data.humid_bytes[1] << 8 | u4Data.data.humid_bytes[0]);

                    u4Data.data.humid = u4Data.data.humid_raw * 100 / 65536;

                    u4Data.zonedata.date = CURRENT_TIME;
                    u4Data.zonedata.zone = 4;
                    u4Data.zonedata.temperatureC = u4Data.data.temp_Celcius;
                    u4Data.zonedata.temperatureF = u4Data.data.temp_Fahrenheit;
                    u4Data.zonedata.humidity = u4Data.data.humid;
                    u4Data.zonedata.pressure = 0;

                    Nop();
                    xQueueSend(dataQueue, u4Data.data_ptr, 10);
                    xQueueSend(u4Status, &u4Data.zonedata.temperatureF, 10);
                    u4Data.data_repeat = 0;
                    Nop();

                    u4Data.prevstate = APP_STATE_DATA_DECODE;
                    u4Data.nextstate = APP_STATE_USART_IDLE;
                    break;

                case APP_STATE_USART_TX_DATA_REQ:
                    u4Data.command = DATA_REQ;
                    u4Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u4Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_RED:
                    u4Data.command = HEATING;
                    u4Data.prevstate = APP_STATE_USART_TX_RED;
                    u4Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_GREEN:
                    u4Data.command = IDLE;
                    u4Data.prevstate = APP_STATE_USART_TX_GREEN;
                    u4Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_BLUE:
                    u4Data.command = COOLING;
                    u4Data.prevstate = APP_STATE_USART_TX_BLUE;
                    u4Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_IDLE:
                    if (DRV_USART_TRANSFER_STATUS_RECEIVER_DATA_PRESENT & DRV_USART_TransferStatus(u4Data.handle)) {
                        // Input detected
                        u4Data.nextstate = APP_STATE_USART_RX;
                    } else if (uxQueueMessagesWaiting(u4command) && (u4Data.data_repeat > 50)) {
                        // if system command in waiting, read it to change state 
                        xQueueReceive(u4command, &u4Data.sys_command, 20);
                        u4Data.nextstate = u4Data.sys_command;
                        u4Data.data_repeat = 0;
                    } else {
                        u4Data.data_repeat++;
                        if (u4Data.data_repeat >= 100) {
                            u4Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
                            u4Data.data_repeat = 0;
                        } else {
                            u4Data.nextstate = APP_STATE_USART_IDLE;
                        }
                    }
                    u4Data.prevstate = APP_STATE_USART_IDLE;
                    vTaskDelay(50);
                    break;

                default:
                    u4Data.nextstate = APP_STATE_USART_IDLE;
                    break;

            }
            vTaskDelay(10);
            Nop();
        } else if(sdReady == false) {
            vTaskDelay(1000);
        } else{
            // Error Processing
            U4_Initialize();
            vTaskDelay(100);
        }
    }
}



/*******************************************************************************
 End of File
 */
