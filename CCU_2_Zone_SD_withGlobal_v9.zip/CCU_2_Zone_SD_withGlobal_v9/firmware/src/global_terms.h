/* 
 * File:   global_terms.h
 * Author: Austin Carter
 *
 * Created on November 26, 2019, 1:10 PM
 */

#ifndef GLOBAL_TERMS_H
#define	GLOBAL_TERMS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "queue.h"
    
    extern QueueHandle_t dataQueue;
    extern QueueHandle_t u1command;
    extern QueueHandle_t u2command;
    extern QueueHandle_t u3command;
    extern QueueHandle_t u4command;
    extern QueueHandle_t u5command;
    extern QueueHandle_t u6command;

    extern QueueHandle_t u1Status;
    extern QueueHandle_t u2Status;
    extern QueueHandle_t u3Status;
    extern QueueHandle_t u4Status;
    extern QueueHandle_t u5Status;
    extern QueueHandle_t u6Status;
    
    extern bool sdStatus;

    typedef enum {
        APP_STATE_USART_INIT = 0,
        APP_STATE_USART_TX,
        APP_STATE_USART_WAIT_FOR_TX_COMPLETION,
        APP_STATE_USART_RX,
        APP_STATE_DATA_DECODE,
        APP_STATE_USART_TX_DATA_REQ,
        APP_STATE_USART_TX_RED,
        APP_STATE_USART_TX_GREEN,
        APP_STATE_USART_TX_BLUE,
        APP_STATE_USART_IDLE
    } SENSOR_UNIT_INTERFACE_STATE;

    typedef struct {
        uint8_t zone;
        uint32_t temperatureC;
        uint32_t temperatureF;
        uint32_t humidity;
        uint32_t pressure;
    } DATA_TRANSFER;

    typedef enum {
        NO_ERROR,
        USART_INIT_FAIL,
    } SYSTEM_ERROR;

    typedef struct {
        uint8_t rec[5];
        uint8_t temp_bytes[2];
        uint16_t temp_raw;
        uint32_t temp_Celcius;
        uint32_t temp_Fahrenheit;
        uint8_t humid_bytes[2];
        uint16_t humid_raw;
        uint32_t humid;
    } DATA_REC;

    typedef enum {
        DATA_REQ = 'r',
        HEATING = 'h',
        IDLE = 's',
        COOLING = 'c'
    } USART_COMMANDS;
#ifdef	__cplusplus
}
#endif

#endif	/* GLOBAL_TERMS_H */

