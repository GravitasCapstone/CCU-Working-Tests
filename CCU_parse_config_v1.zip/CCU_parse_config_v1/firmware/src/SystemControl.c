/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    systemcontrol.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "systemcontrol.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

SYSTEMCONTROL_DATA systemcontrolData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void SYSTEMCONTROL_Initialize ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

bool sdMount = false;
bool sdConfig_read = false;
bool sdSchedule_read = false;
SYS_FS_HANDLE datalog, config, schedule;
SYS_FS_RESULT mount, drive_set, unmount;
SYS_FS_RESULT datalog_close, config_close, schedule_close;
SYS_FS_ERROR err;
size_t datalog_bytes_written, config_bytes_read, schedule_bytes_read;
size_t config_file_size, schedule_file_size;

QueueHandle_t u1command;
QueueHandle_t u2command;
QueueHandle_t u3command;
QueueHandle_t u4command;
QueueHandle_t u5command;
QueueHandle_t u6command;

QueueHandle_t u1Status;
QueueHandle_t u2Status;
QueueHandle_t u3Status;
QueueHandle_t u4Status;
QueueHandle_t u5Status;
QueueHandle_t u6Status;

char *com = ",";
char *newline = "\n";

char config_buff[500];
char schedule_buff[4000];

char *res[80];

char *config_table[40][2];
char *config_buff_ptr;
int i, j;

void SYSTEMCONTROL_Initialize(void) {
    u1command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u2command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u3command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u4command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u5command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u6command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));

    u1Status = xQueueCreate(5, sizeof (uint32_t));
    u2Status = xQueueCreate(5, sizeof (uint32_t));
    u3Status = xQueueCreate(5, sizeof (uint32_t));
    u4Status = xQueueCreate(5, sizeof (uint32_t));
    u5Status = xQueueCreate(5, sizeof (uint32_t));
    u6Status = xQueueCreate(5, sizeof (uint32_t));



    systemcontrolData.prevstate = SYSTEMCONTROL_STATE_INIT;
    systemcontrolData.nextstate = SYSTEMCONTROL_STATE_MOUNT_SD;

}

/******************************************************************************
  Function:
    void SYSTEMCONTROL_Tasks ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

void SYSTEMCONTROL_Tasks(void) {
    while (1) {
        switch (systemcontrolData.nextstate) {
            case SYSTEMCONTROL_STATE_MOUNT_SD:
                mount = SYS_FS_Mount("/dev/mmcblka1", "/mnt/myDrive", FAT, 0, NULL);
                if (mount == 0) {
                    sdMount = true;
                    BSP_LEDOn(LED3);
                    drive_set = SYS_FS_CurrentDriveSet("/mnt/myDrive");
                    err = SYS_FS_Error();
                    systemcontrolData.prevstate = SYSTEMCONTROL_STATE_MOUNT_SD;
                    systemcontrolData.nextstate = SYSTEMCONTROL_STATE_READ_CONFIG;
                    sdMount = true;
                    Nop();
                } else {
                    err = SYS_FS_Error();
                    BSP_LEDToggle(LED3);
                    Nop();
                }
                break;

            case SYSTEMCONTROL_STATE_READ_CONFIG:
                BSP_LEDOn(LED3);
                config = SYS_FS_FileOpen("config.csv", (SYS_FS_FILE_OPEN_READ));
                if (config == SYS_FS_HANDLE_INVALID) {
                    Nop();
                }
                config_file_size = SYS_FS_FileSize(config);
                if (config_file_size == -1) {
                    Nop();
                }
                config_bytes_read = SYS_FS_FileRead(config, config_buff, config_file_size);
                if (config_bytes_read != -1) {
                    Nop();
                }
                config_close = SYS_FS_FileClose(config);
                if (config_close == -1) {
                    Nop();
                }
                err = SYS_FS_Error();
                systemcontrolData.prevstate = SYSTEMCONTROL_STATE_READ_CONFIG;
                systemcontrolData.nextstate = SYSTEMCONTROL_STATE_PROCESS_CONFIG;
                BSP_LEDOff(LED3);
                sdConfig_read = true;
                Nop();
                // need to implement processing
                break;

            case SYSTEMCONTROL_STATE_PROCESS_CONFIG:
                Nop();

                // trust me it works.... just see the leds later 
                res[i] = strtok(config_buff, "\n,");
                while (res[i] != NULL) {
                    res[++i] = strtok(NULL, "\n,");
                }

                for (j = 0; j <= 40; j++) {
                    config_table[j][0] = res[2 * j];
                    config_table[j][1] = res[2 * j + 1];
                }
                Nop();
                if ((strcmp(config_table[1][0], "z1") == 0)&&(strcmp(config_table[1][1], "1") == 0)) { // line 2 of csv "z1,1"
                    BSP_LEDOn(LED1);
                    Nop();
                }
                if ((strcmp(config_table[13][0], "d1Z") == 0)&&(strcmp(config_table[13][1], "1") == 0)) { // line 14 of csv "d1Z,1
                    BSP_LEDOn(LED2);
                    Nop();
                }

                for (i = 0; i < 4; i++) {
                    j = atoi(config_table[i + 1][1]);
                    systemcontrolData.config.zone[i] = j;
                }
                for (i = 0; i < 8; i++) {
                    j = atoi(config_table[i + 5][1]);
                    systemcontrolData.config.damper[i] = j;
                }
                for (i = 0; i < 8; i++) {
                    j = atoi(config_table[i + 13][1]);
                    systemcontrolData.config.damper_in_zone[i] = j;
                }
                for (i = 0; i < 8; i++) {
                    j = atoi(config_table[i + 21][1]);
                    systemcontrolData.config.damper_mode[i] = j;
                }
                i = 29;
                systemcontrolData.config.ahu.cSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cAnt,config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cRunT,config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cCycleT,config_table[i++][1]);
                systemcontrolData.config.ahu.hSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hAnt,config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hRunT,config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hCycleT,config_table[i++][1]);
                systemcontrolData.config.ahu.overTemp = atoi(config_table[i++][1]);
                
                Nop();
                break;
        }
        Nop();
        vTaskDelay(100);
    }
}


/*******************************************************************************
 End of File
 */
