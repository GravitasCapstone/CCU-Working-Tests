/* 
 * File:   global_terms.h
 * Author: Austin Carter
 *
 * Created on November 26, 2019, 1:10 PM
 */

#ifndef GLOBAL_TERMS_H
#define	GLOBAL_TERMS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "queue.h"

#define prep_day_offset 0
#define prep_hour_offset 0
#define prep_min_offset 0
#define prep_sec_offset 15    

#define idle_day_offset 0    
#define idle_hour_offset 0
#define idle_min_offset 1
#define idle_sec_offset 30

#define config_day_offset 0    
#define config_hour_offset 1
#define config_min_offset 30
#define config_sec_offset 0

    extern QueueHandle_t dataQueue;

    extern QueueHandle_t u1command;
    extern QueueHandle_t u2command;
    extern QueueHandle_t u3command;
    extern QueueHandle_t u4command;
    extern QueueHandle_t u5command;
    extern QueueHandle_t u6command;

    extern QueueHandle_t u1Status;
    extern QueueHandle_t u2Status;
    extern QueueHandle_t u3Status;
    extern QueueHandle_t u4Status;
    extern QueueHandle_t u5Status;
    extern QueueHandle_t u6Status;

    extern QueueHandle_t ccu_command;

    extern bool sdMount, sdConfig_read, sdSchedule_read, sdReady, logReady;

    extern bool z1En, z2En, z3En, z4En;

    extern SYS_FS_HANDLE datalog, config, schedule;
    extern SYS_FS_RESULT mount, drive_set, unmount;
    extern SYS_FS_RESULT datalog_close, config_close, schedule_close;
    extern SYS_FS_ERROR err;
    extern size_t datalog_bytes_written, config_bytes_read, schedule_bytes_read;
    extern size_t config_file_size, schedule_file_size;

    extern uint32_t heartbeat;
    extern char *com;
    extern char *newline;
    extern char *colon;
    extern char CURRENT_TIME[10];

    typedef enum {
        SUNDAY = 0,
        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY
    } DAYS;

    extern char *SUNDAY_STR;
    extern char * MONDAY_STR;
    extern char * TUESDAY_STR;
    extern char * WEDNESDAY_STR;
    extern char * THURSDAY_STR;
    extern char * FRIDAY_STR;
    extern char * SATURDAY_STR;

    extern uint8_t CURRENT_HOUR;
    extern uint8_t CURRENT_MIN;
    extern uint8_t CURRENT_SEC;
    extern DAYS CURRENT_DAY;

    typedef struct {
        DAYS day;
        uint8_t hour;
        uint8_t minute;
        uint8_t second;
    } TIME_PROCESS;

    typedef enum {
        ZONE_DISABLED = 0,
        ZONE_ENABLED
    } ZONE_ENABLE;

    typedef struct {
        uint8_t day;
        uint8_t zone_responsible;
        char start_time[10];
        char end_time[10];
        uint8_t lowpointF;
        uint8_t highpointF;
    } SCHEDULE_LINE;

    typedef enum {
        DAMPER_DISABLED = 0,
        DAMPER_NORMALLY_OPEN,
        DAMPER_NORMALLY_CLOSED
    } DAMPER_ENABLE;

    typedef enum {
        DAMPER_NO_ZONE_DISABLED = 0,
        DAMPER_IN_Z1,
        DAMPER_IN_Z2,
        DAMPER_IN_Z3,
        DAMPER_IN_Z4,
    } DAMPER_LOCATION;

    typedef enum {
        DAMPER_NORMAL = 0,
        DAMPER_NO_HEAT,
        DAMPER_NO_COOL
    } DAMPER_OPERATION;

    typedef enum {
        SYS_SINGLE_FAN = 0,
        SYS_DOUBLE_FAN,
        SYS_TRIPLE_FAN
    } AIR_HANDLER_SYS;

    typedef struct {
        AIR_HANDLER_SYS cSys;
        char cAnt[8];
        char cRunT[8];
        char cCycleT[8];
        TIME_PROCESS coolAnt;
        TIME_PROCESS coolRunT;
        TIME_PROCESS coolCycleT;
        AIR_HANDLER_SYS hSys;
        char hAnt[8];
        char hRunT[8];
        char hCycleT[8];
        TIME_PROCESS heatAnt;
        TIME_PROCESS heatRunT;
        TIME_PROCESS heatCycleT;
        uint8_t overTemp;
    } AIR_HANDLER_UNIT;

    typedef struct {
        ZONE_ENABLE zone[4];
        DAMPER_ENABLE damper[8];
        DAMPER_LOCATION damper_in_zone[8];
        DAMPER_OPERATION damper_mode[8];
        AIR_HANDLER_UNIT ahu;
    } SYSTEM_CONFIG;

    typedef struct {
        uint8_t dampers;
        uint8_t cut_air_command;
        uint8_t allow_air_command;
        uint8_t send_heat;
        uint8_t send_cool;
    } ZONE_CONFIG;

    typedef enum {
        HVAC_READY,
        HVAC_IDLE,
        HVAC_COOL_PREP,
        HVAC_COOLING,
        HVAC_COOL_DOWN,
        HVAC_HEAT_PREP,
        HVAC_HEATING,
        HVAC_HEAT_DOWN,
        HVAC_BOOTUP,
        HVAC_SETUP_CHECK
    } HVAC_STATUS;

    typedef enum {
        ZONE_NEED_HEAT,
        ZONE_NEED_COOL,
        ZONE_HEATING,
        ZONE_COOLING,
        ZONE_IDLE
    } ZONE_NEEDS;

    typedef struct {
        char* date;
        uint8_t zone;
        uint32_t temperatureC;
        uint32_t temperatureF;
        uint32_t humidity;
        uint32_t pressure;
    } DATA_TRANSFER;

    typedef struct {
        uint8_t zone;
        ZONE_NEEDS zone_needs_mode;
        DATA_TRANSFER status;
        ZONE_NEEDS zone_in_mode;
    } ZONE_STATUS;

    typedef enum {
        APP_STATE_USART_INIT = 0, // Initialize the USART port for specific unit
        APP_STATE_USART_TX, // Send command to sensor unit
        APP_STATE_USART_WAIT_FOR_TX_COMPLETION, // Trigger to set CCU line driver to receive mode after all of TX is done
        APP_STATE_USART_RX, // Get response from sensor unit 
        APP_STATE_DATA_DECODE, // Decode sensor data from the sensor unit
        APP_STATE_USART_TX_DATA_REQ, // Set next command to request sensor data
        APP_STATE_USART_TX_RED, // Set next command to turn RGB to Red
        APP_STATE_USART_TX_GREEN, // Set next command to turn RGB to Green
        APP_STATE_USART_TX_BLUE, // Set next command to turn RGB to Blue
        APP_STATE_USART_IDLE, // Wait for next update from unit
        APP_STATE_USART_DISABLED // Idle until system config enables the port
    } SENSOR_UNIT_INTERFACE_STATE;

    typedef enum {
        SENSORLOG_STATE_INIT = 0,
        SENSORLOG_STATE_WAIT_FOR_SD_MOUNT,
        SENSORLOG_STATE_DATALOG_SETUP,
        SENSORLOG_STATE_ACTIVE,
        SENSORLOG_STATE_IDLE
    } SENSORLOG_STATES;

    typedef enum {
        SYSTEMCONTROL_STATE_INIT = 0,
        SYSTEMCONTROL_STATE_MOUNT_SD,
        SYSTEMCONTROL_STATE_READ_CONFIG,
        SYSTEMCONTROL_STATE_PROCESS_CONFIG,
        SYSTEMCONTROL_STATE_APPLY_CONFIG,
        SYSTEMCONTROL_STATE_READ_SCHEDULE,
        SYSTEMCONTROL_STATE_PROCESS_SCHEDULE,
        SYSTEMCONTROL_GET_DATA,
        SYSTEMCONTROL_GET_HVAC_MODE,
        SYSTEMCONTROL_THRESHOLD_CHECK,
        SYSTEMCONTROL_GROUP_NEEDS,
        SYSTEMCONTROL_DETERMINE_NEXT_ACTION,
        SYSTEMCONTROL_ACT
    } SYSTEMCONTROL_STATES;

    typedef enum {
        NO_ERROR,
        USART_OPEN_FAIL,
        SD_MOUNT_FAIL,
        NETWORK_NC,
        SENSOR_DATA_RETURN_TIMEOUT
    } SYSTEM_ERROR;

    typedef struct {
        uint8_t rec[5];
        uint8_t temp_bytes[2];
        uint16_t temp_raw;
        uint32_t temp_Celcius;
        uint32_t temp_Fahrenheit;
        uint8_t humid_bytes[2];
        uint16_t humid_raw;
        uint32_t humid;
    } DATA_REC;

    typedef enum {
        DATA_REQ = 'r',
        HEATING = 'h',
        IDLE = 's',
        COOLING = 'c'
    } USART_COMMANDS;


#ifdef	__cplusplus
}
#endif

#endif	/* GLOBAL_TERMS_H */

