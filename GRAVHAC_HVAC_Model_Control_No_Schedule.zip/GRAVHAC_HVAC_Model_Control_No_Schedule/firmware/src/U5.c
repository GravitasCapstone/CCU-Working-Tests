/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    u5.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "u5.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

U5_DATA u5Data;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void U5_Initialize ( void )

  Remarks:
    See prototype in u5.h.
 */




void U5_Initialize(void) {
    u5Data.prevstate = APP_STATE_USART_INIT;
    u5Data.handle = DRV_USART_Open(DRV_USART_INDEX_4, DRV_IO_INTENT_READWRITE);
    if (u5Data.handle == DRV_HANDLE_INVALID) {
        u5Data.error = USART_OPEN_FAIL;
    } else {
        u5Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
        u5Data.error = NO_ERROR;
        BSP_LEDStateSet(U5_EN, 0);
    }
    u5Data.data_ptr = &u5Data.zonedata;
}

/******************************************************************************
  Function:
    void U5_Tasks ( void )

  Remarks:
    See prototype in u5.h.
 */
void U5_Tasks(void) {
    while (1) {
        if ((u5Data.error == NO_ERROR) && ((sdMount && sdConfig_read && sdSchedule_read) == true)) {
            switch (u5Data.nextstate) {
                case APP_STATE_USART_TX:
                    // set 485 to TX
                    BSP_LEDStateSet(U5_EN, 1);
                    // send data
                    DRV_USART_Write(u5Data.handle, &u5Data.command, sizeof (char));
                    u5Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u5Data.nextstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                    vTaskDelay(10);
                    break;
                case APP_STATE_USART_WAIT_FOR_TX_COMPLETION:
                    if (DRV_USART_TRANSFER_STATUS_TRANSMIT_EMPTY & DRV_USART_TransferStatus(u5Data.handle)) {
                        // TX complete and prep for RX
                        BSP_LEDStateSet(U5_EN, 0);
                        u5Data.prevstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                        u5Data.nextstate = APP_STATE_USART_IDLE;
                    }
                    break;
                case APP_STATE_USART_RX:
                    DRV_USART_Read(u5Data.handle, &u5Data.data.rec[0], 4);
                    u5Data.prevstate = APP_STATE_USART_RX;
                    u5Data.nextstate = APP_STATE_DATA_DECODE;
                    Nop();
                    vTaskDelay(10);
                    break;
                case APP_STATE_DATA_DECODE:
                    u5Data.data.temp_bytes[0] = u5Data.data.rec[0];
                    u5Data.data.temp_bytes[1] = u5Data.data.rec[1];

                    u5Data.data.temp_raw = (unsigned int) (u5Data.data.temp_bytes[1] << 8 | u5Data.data.temp_bytes[0]);

                    u5Data.data.temp_Celcius = ((u5Data.data.temp_raw * 165) / 65536) - 40;
                    u5Data.data.temp_Fahrenheit = u5Data.data.temp_Celcius * 9 / 5 + 32;

                    u5Data.data.humid_bytes[0] = u5Data.data.rec[2];
                    u5Data.data.humid_bytes[1] = u5Data.data.rec[3];

                    u5Data.data.humid_raw = (u5Data.data.humid_bytes[1] << 8 | u5Data.data.humid_bytes[0]);

                    u5Data.data.humid = u5Data.data.humid_raw * 100 / 65536;

                    u5Data.zonedata.date = CURRENT_TIME;
                    u5Data.zonedata.zone = 5;
                    u5Data.zonedata.temperatureC = u5Data.data.temp_Celcius;
                    u5Data.zonedata.temperatureF = u5Data.data.temp_Fahrenheit;
                    u5Data.zonedata.humidity = u5Data.data.humid;
                    u5Data.zonedata.pressure = 0;

                    Nop();
                    xQueueSend(dataQueue, u5Data.data_ptr, 10);
                    xQueueSend(u5Status, &u5Data.zonedata.temperatureF, 10);
                    u5Data.data_repeat = 0;
                    Nop();

                    u5Data.prevstate = APP_STATE_DATA_DECODE;
                    u5Data.nextstate = APP_STATE_USART_IDLE;
                    break;

                case APP_STATE_USART_TX_DATA_REQ:
                    u5Data.command = DATA_REQ;
                    u5Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_RED:
                    u5Data.command = HEATING;
                    u5Data.prevstate = APP_STATE_USART_TX_RED;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_GREEN:
                    u5Data.command = IDLE;
                    u5Data.prevstate = APP_STATE_USART_TX_GREEN;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_BLUE:
                    u5Data.command = COOLING;
                    u5Data.prevstate = APP_STATE_USART_TX_BLUE;
                    u5Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_IDLE:
                    if (DRV_USART_TRANSFER_STATUS_RECEIVER_DATA_PRESENT & DRV_USART_TransferStatus(u5Data.handle)) {
                        // Input detected
                        u5Data.nextstate = APP_STATE_USART_RX;
                    } else if (uxQueueMessagesWaiting(u5command)) {
                        // if system command in waitng, read it to change state 
                        xQueueReceive(u5command, &u5Data.sys_command, 20);
                        u5Data.nextstate = u5Data.sys_command;
                        u5Data.data_repeat = 0;
                    } else {
                        u5Data.data_repeat++;
                        if (u5Data.data_repeat >= 100) {
                            u5Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
                            u5Data.data_repeat = 0;
                        } else {
                            u5Data.nextstate = APP_STATE_USART_IDLE;
                        }
                    }
                    u5Data.prevstate = APP_STATE_USART_IDLE;
                    vTaskDelay(50);
                    break;

                default:
                    u5Data.nextstate = APP_STATE_USART_IDLE;
                    break;

            }
            vTaskDelay(10);
            Nop();
        } else if(sdReady == false) {
            vTaskDelay(1000);
        } else{
            // Error Processing
            U5_Initialize();
            vTaskDelay(100);
        }
    }
}



/*******************************************************************************
 End of File
 */
